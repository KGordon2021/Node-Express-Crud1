const mysql = require('mysql'); //where our data base is stored 
const express = require('express'); // a module ideal for routing and template engines
const bodyparser = require('body-parser'); // gives direct access to the req.body
const ejs = require('ejs');

 //assigning a path and rounter for our application
 const path = require('path');
 const router = express.Router();
 
 //Setup Express
 var app = express();

 //Configuring express server
//  app.use(bodyparser.json()); -- updated to info below
    app.use(express.json());
    app.use('/', router);
    app.use(express.urlencoded());
    app.use('/public', express.static('public'));// code to use scripts, this is route specific which means it can be used only on specified routes
    app.set('view engine', 'ejs'); //here we say what we are setting which is view engine and which engine which is ejs it looks for a folder called views by default

    
 var conn = mysql.createConnection({
    host: "localhost",   
    user: "root",    
    password: "Kristine@2018",   
    database: "nodeexpresscrud"  
  });

  
  conn.connect((err)=> {
    if(!err)
        console.log('Connected to database Successfully');
    else
        console.log('Connection Failed!'+ JSON.stringify(err,undefined,2));
    });


//Specify the Port to listen on
const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`Listening on port ${port}..`));

//setting up routers
router.get('/',function(req,res){
    res.render('../views/pages/home');
   });

// router.get('/allRecords',function(req,res){ // this router is used to pass data to show exiting records and as such is not required here
// res.render('../views/pages/allRecords');
// });

router.get('/new_Rec',function(req,res){
res.render('../views/pages/addProject');
});



//POST Router to Add trainers from the form
 app.post('/addProject/add' , (req, res) => {
    let data = {    project_title:     req.body.proj_title, 
                    project_description: req.body.dets, 
                    project_start_dt: req.body.rec_date, 
                    project_due_dt: req.body.comp_date,
                };

        let sqlQuery = "INSERT INTO projects SET ?";
    //  let sqlQuery = "INSERT INTO students (frst_nm, last_nm, email_addr, cohort) VALUES ('"+ req.body.first_name +"', '" + req.body.last_name + "', '"+ req.body.email_address + "','" + req.body.cohort_number +  "') ";
    
        let vQuery = conn.query(sqlQuery, data,(err, results) => {
        if(err) throw err;
        res.send(JSONResponse(results));
        });
    }); 

// //Create GET Router to fetch all the projects in Database
// app.get('/existing_Recs' , (req, res) => {
//     conn.query('SELECT * FROM nodeexpresscrud.projects', (err, rows, fields) => {
//         if (err)
//         res.render('existing_Recs', {
//             doc_Title: "All Projects",
//             data: '',
//             });
//         else {
//             res.render('existing_Recs', {
//                 doc_Title: "All Projects",
//                 data: rows,
//         });
//         console.log(err);
//        }
//     });
//  });

    //Create GET Router to fetch all the class trainers Database
    // app.get('/existing_Rec' , (req, res) => {
    //     conn.query('SELECT * FROM nodeexpresscrud.projects', (err, rows, fields) => {
    //         if (!err)
    //             res.send(rows);
    //         else
    //             console.log(err);
    //         })
    //     });


    router.get('/existing_Recs', function(req, res, next) { //route has to be declared once
        conn.query('SELECT * FROM nodeexpresscrud.projects',function(err, rows){
               if(err){
                   res.render('pages/allRecords', // was in incorrect file path
                   {data:''});   
               }else{
                   res.render('pages/allRecords', 
                   {data: rows});
               }                          
                });
           });